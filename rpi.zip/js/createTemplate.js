function openCreateTemplate() {
	document.getElementById("createTemplate").style.display = "inline";
	document.getElementById("background").style.display = "inline";
	closeNav();
}

function closeAll(){
	document.getElementById("createTemplate").style.display = "none";
	document.getElementById("createSchedule").style.display = "none";
	document.getElementById("background").style.display = "none";
}

function openCreateSchedule() {
	document.getElementById("createSchedule").style.display = "inline";
	document.getElementById("background").style.display = "inline";
	closeNav();
}
function updateWattage(x, wattage) {

	var id = "wattage" + x;

	document.getElementById(id).innerHTML = wattage + " kW";

}
function toogleSwitch1() {
	document.getElementById("button1").click();
}

function toogleSwitch2() {
	document.getElementById("button2").click();
}

function toogleSwitch3() {
	document.getElementById("button3").click();
}

function toogleSwitch4() {
	document.getElementById("button4").click();
}

function toogleSwitch5() {
	document.getElementById("button5").click();
}

function toogleSwitch6() {
	document.getElementById("button6").click();
}

function toogleSwitch7() {
	document.getElementById("button7").click();
}

function toogleSwitch8() {
	document.getElementById("button8").click();
}